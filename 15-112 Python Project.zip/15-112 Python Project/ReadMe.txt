Make sure game_files folder is in same location as project.py

Make sure pygame library is installed